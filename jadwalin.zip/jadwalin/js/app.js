import { supabase, isConfigured } from "../services/supabase.js";
import { getSettings, getProfile } from "../services/settings-service.js";
import { getSchedules } from "../services/jadwal-service.js";
import { applyTheme } from "./theme.js";
import { startReminders } from "./reminder.js";
import { logout } from "./auth.js";

export const DAYS = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"];

// 1 = Senin ... 7 = Minggu (sesuai kolom day_of_week)
export function todayDow() {
  const d = new Date().getDay();
  return d === 0 ? 7 : d;
}

export function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

export function safeColor(c) {
  return /^#[0-9a-fA-F]{6}$/.test(c || "") ? c : "#4f46e5";
}

export const fmt = (t) => (t || "").slice(0, 5);

export function nowMinutes() {
  const n = new Date();
  return n.getHours() * 60 + n.getMinutes();
}

export function toast(message, type = "") {
  let host = document.getElementById("toast-host");
  if (!host) {
    host = document.createElement("div");
    host.id = "toast-host";
    document.body.appendChild(host);
  }
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = message;
  host.appendChild(el);
  setTimeout(() => el.remove(), 4500);
}

export function errorMessage(err) {
  const msg = (err && err.message) || String(err);
  if (/Failed to fetch|NetworkError/i.test(msg)) return "Tidak bisa terhubung ke server. Cek koneksi internet kamu.";
  return msg;
}

function setupNotice() {
  document.body.innerHTML = `
    <div class="auth-wrap"><div class="card auth-card">
      <div class="brand">Jadwalin</div>
      <h2>Supabase belum dikonfigurasi</h2>
      <p class="muted">Buka <code>services/supabase.js</code> lalu isi <code>SUPABASE_URL</code> dan
      <code>SUPABASE_ANON_KEY</code> dari project Supabase kamu. Detailnya ada di README.md.</p>
    </div></div>`;
}

const NAV = [
  { key: "dashboard", href: "dashboard.html", label: "Dashboard", icon: "🏠" },
  { key: "jadwal", href: "jadwal.html", label: "Jadwal", icon: "📅" },
  { key: "pengaturan", href: "pengaturan.html", label: "Pengaturan", icon: "⚙️" },
];

// Dipanggil oleh setiap halaman terproteksi.
// Mengembalikan { user, settings, profile, page } atau null jika dialihkan.
export async function initPage({ active, title }) {
  if (!isConfigured) { setupNotice(); return null; }

  const { data } = await supabase.auth.getSession();
  const session = data && data.session;
  if (!session) { location.replace("login.html"); return null; }
  const user = session.user;

  let settings = { theme: "light", reminder_enabled: false, reminder_minutes: 10 };
  let profile = null;
  try {
    [settings, profile] = await Promise.all([getSettings(user.id), getProfile(user.id)]);
  } catch (err) {
    console.error(err);
  }
  applyTheme(settings.theme);

  const name = (profile && profile.display_name) || (user.email || "").split("@")[0] || "Pengguna";

  const root = document.getElementById("app");
  root.className = "app";
  root.innerHTML = `
    <aside class="sidebar" id="sidebar">
      <div class="brand">📘 Jadwalin</div>
      <nav class="nav">
        ${NAV.map((n) => `<a href="${n.href}" class="${n.key === active ? "active" : ""}"><span>${n.icon}</span>${n.label}</a>`).join("")}
      </nav>
      <div class="sidebar-footer">
        <button class="btn btn-ghost btn-block" id="logout-btn">Keluar</button>
      </div>
    </aside>
    <div class="main">
      <header class="topbar">
        <div class="topbar-left">
          <button class="btn btn-secondary btn-sm menu-btn" id="menu-btn" aria-label="Buka menu">☰</button>
          <h1 style="margin:0">${esc(title)}</h1>
        </div>
        <div class="profile">
          <span class="profile-name muted" id="profile-name">${esc(name)}</span>
          <div class="avatar" id="avatar">${esc(name.charAt(0).toUpperCase())}</div>
        </div>
      </header>
      <main class="content" id="page"><div class="loading"><span class="spinner"></span></div></main>
    </div>`;

  const sidebar = document.getElementById("sidebar");
  let overlay = null;
  const closeMenu = () => { sidebar.classList.remove("open"); overlay && overlay.remove(); overlay = null; };
  document.getElementById("menu-btn").addEventListener("click", () => {
    sidebar.classList.add("open");
    overlay = document.createElement("div");
    overlay.className = "sidebar-overlay";
    overlay.addEventListener("click", closeMenu);
    document.body.appendChild(overlay);
  });
  document.getElementById("logout-btn").addEventListener("click", logout);

  startReminders({
    getSchedules,
    enabled: settings.reminder_enabled,
    minutes: settings.reminder_minutes,
    onNotify: (msg) => toast(msg, "ok"),
  });

  return { user, settings, profile, name, page: document.getElementById("page") };
}

// Update nama/inisial di header setelah profil diubah
export function updateHeaderName(name) {
  const n = document.getElementById("profile-name");
  const a = document.getElementById("avatar");
  if (n) n.textContent = name;
  if (a) a.textContent = name.charAt(0).toUpperCase();
}

export function confirmDialog(message, okLabel = "Hapus") {
  return new Promise((resolve) => {
    const back = document.createElement("div");
    back.className = "modal-backdrop";
    back.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true">
        <h2>Konfirmasi</h2>
        <p>${esc(message)}</p>
        <div class="modal-actions">
          <button class="btn btn-secondary" data-r="0">Batal</button>
          <button class="btn btn-danger" data-r="1">${esc(okLabel)}</button>
        </div>
      </div>`;
    back.addEventListener("click", (e) => {
      const r = e.target.getAttribute && e.target.getAttribute("data-r");
      if (r !== null || e.target === back) { back.remove(); resolve(r === "1"); }
    });
    document.body.appendChild(back);
  });
}
