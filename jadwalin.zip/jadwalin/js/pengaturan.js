import { initPage, esc, toast, errorMessage, updateHeaderName } from "./app.js";
import { saveSettings, saveProfile } from "../services/settings-service.js";
import { applyTheme } from "./theme.js";
import { requestPermission, notificationsSupported, configureReminders } from "./reminder.js";

(async function main() {
  const ctx = await initPage({ active: "pengaturan", title: "Pengaturan" });
  if (!ctx) return;
  const { page, user } = ctx;
  const s = { ...ctx.settings };
  const profileName = ctx.name;

  const permNote = () => {
    if (!notificationsSupported()) return "Browser ini tidak mendukung notifikasi.";
    if (Notification.permission === "denied") return "Notifikasi diblokir di browser. Izinkan lewat pengaturan situs.";
    if (Notification.permission === "granted") return "Izin notifikasi sudah diberikan.";
    return "Browser akan meminta izin notifikasi saat pengingat diaktifkan.";
  };

  page.innerHTML = `
    <div class="grid grid-2">
      <div class="card">
        <h2>Profil</h2>
        <div class="field">
          <label for="p-name">Nama tampilan</label>
          <input class="input" id="p-name" maxlength="40" value="${esc(profileName)}" />
        </div>
        <div class="field"><label>Email</label><div class="muted">${esc(user.email)}</div></div>
        <button class="btn" id="save-profile">Simpan profil</button>
      </div>

      <div class="card">
        <h2>Tema</h2>
        <div class="theme-options" id="theme-options">
          <button class="theme-opt ${s.theme === "light" ? "active" : ""}" data-theme-val="light">☀️ Terang</button>
          <button class="theme-opt ${s.theme === "dark" ? "active" : ""}" data-theme-val="dark">🌙 Gelap</button>
        </div>
        <p class="muted" style="margin-top:.75rem">Pilihan tema tersimpan di akunmu.</p>
      </div>

      <div class="card" style="grid-column: 1 / -1">
        <h2>Pengingat pelajaran</h2>
        <div class="setting-row">
          <div>
            <b>Aktifkan pengingat</b>
            <div class="muted" id="perm-note">${permNote()}</div>
          </div>
          <label class="switch">
            <input type="checkbox" id="rem-enabled" ${s.reminder_enabled ? "checked" : ""} />
            <span class="slider"></span>
          </label>
        </div>
        <div class="setting-row">
          <div><b>Ingatkan sebelum mulai</b></div>
          <select class="input" id="rem-minutes" style="width:auto">
            ${[5, 10, 15].map((m) => `<option value="${m}" ${Number(s.reminder_minutes) === m ? "selected" : ""}>${m} menit</option>`).join("")}
          </select>
        </div>
        <p class="muted" style="margin:.75rem 0 0">Pengingat berjalan selama tab Jadwalin terbuka di browser.</p>
      </div>
    </div>`;

  const $ = (id) => document.getElementById(id);

  // ----- tema -----
  $("theme-options").addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-theme-val]");
    if (!btn) return;
    const theme = btn.dataset.themeVal;
    if (theme === s.theme) return;
    const prev = s.theme;
    s.theme = theme;
    applyTheme(theme);
    page.querySelectorAll(".theme-opt").forEach((b) => b.classList.toggle("active", b.dataset.themeVal === theme));
    try {
      await saveSettings(user.id, { theme });
      toast("Tema disimpan", "ok");
    } catch (err) {
      s.theme = prev;
      applyTheme(prev);
      page.querySelectorAll(".theme-opt").forEach((b) => b.classList.toggle("active", b.dataset.themeVal === prev));
      toast("Gagal menyimpan tema: " + errorMessage(err), "error");
    }
  });

  // ----- pengingat -----
  async function saveReminder() {
    const enabledEl = $("rem-enabled");
    let enabled = enabledEl.checked;
    const minutes = Number($("rem-minutes").value);

    if (enabled) {
      const perm = await requestPermission();
      $("perm-note").textContent = permNote();
      if (perm !== "granted") {
        toast("Izin notifikasi tidak diberikan, pengingat tidak aktif.", "error");
        enabledEl.checked = false;
        enabled = false;
      }
    }
    try {
      await saveSettings(user.id, { reminder_enabled: enabled, reminder_minutes: minutes });
      configureReminders({ enabled, minutes });
      toast("Pengaturan pengingat disimpan", "ok");
    } catch (err) {
      toast("Gagal menyimpan: " + errorMessage(err), "error");
    }
  }
  $("rem-enabled").addEventListener("change", saveReminder);
  $("rem-minutes").addEventListener("change", saveReminder);

  // ----- profil -----
  $("save-profile").addEventListener("click", async () => {
    const btn = $("save-profile");
    if (btn.disabled) return;
    const name = $("p-name").value.trim();
    if (!name) return toast("Nama tidak boleh kosong.", "error");
    btn.disabled = true;
    try {
      await saveProfile(user.id, name);
      updateHeaderName(name);
      toast("Profil disimpan", "ok");
    } catch (err) {
      toast("Gagal menyimpan profil: " + errorMessage(err), "error");
    } finally {
      btn.disabled = false;
    }
  });
})();
