import { supabase, isConfigured } from "../services/supabase.js";

export function translateAuthError(err) {
  const msg = ((err && err.message) || "").toLowerCase();
  if (msg.includes("invalid login")) return "Email atau password salah.";
  if (msg.includes("email not confirmed")) return "Email belum dikonfirmasi. Cek inbox kamu.";
  if (msg.includes("already registered") || msg.includes("already been registered")) return "Email ini sudah terdaftar. Silakan masuk.";
  if (msg.includes("password should be")) return "Password minimal 6 karakter.";
  if (msg.includes("rate limit")) return "Terlalu banyak percobaan. Coba lagi beberapa saat lagi.";
  if (msg.includes("failed to fetch") || msg.includes("network")) return "Tidak bisa terhubung ke server. Cek koneksi internet kamu.";
  return (err && err.message) || "Terjadi kesalahan. Coba lagi.";
}

export async function logout() {
  try { await supabase.auth.signOut(); } catch (e) { console.error(e); }
  location.replace("login.html");
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export async function initLoginPage() {
  const form = document.getElementById("auth-form");
  const emailEl = document.getElementById("email");
  const passEl = document.getElementById("password");
  const btn = document.getElementById("submit-btn");
  const msg = document.getElementById("auth-msg");
  const title = document.getElementById("auth-title");
  const switchBtn = document.getElementById("switch-btn");
  const switchText = document.getElementById("switch-text");

  if (!isConfigured) {
    msg.className = "alert alert-warn";
    msg.textContent = "Supabase belum dikonfigurasi. Isi services/supabase.js dulu (lihat README).";
    btn.disabled = true;
    return;
  }

  // sudah login? langsung ke dashboard
  const { data } = await supabase.auth.getSession();
  if (data && data.session) { location.replace("dashboard.html"); return; }

  let mode = "login"; // "login" | "register"
  const show = (text, type = "error") => {
    msg.className = `alert alert-${type}`;
    msg.textContent = text;
    msg.classList.remove("hidden");
  };
  const clear = () => msg.classList.add("hidden");

  function setMode(m) {
    mode = m;
    clear();
    const reg = m === "register";
    title.textContent = reg ? "Buat akun" : "Masuk";
    btn.textContent = reg ? "Daftar" : "Masuk";
    switchText.textContent = reg ? "Sudah punya akun?" : "Belum punya akun?";
    switchBtn.textContent = reg ? "Masuk" : "Daftar";
    passEl.autocomplete = reg ? "new-password" : "current-password";
  }
  switchBtn.addEventListener("click", () => setMode(mode === "login" ? "register" : "login"));

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (btn.disabled) return; // cegah kirim ganda
    clear();

    const email = emailEl.value.trim();
    const password = passEl.value;
    if (!EMAIL_RE.test(email)) return show("Format email tidak valid.");
    if (password.length < 6) return show("Password minimal 6 karakter.");

    const label = btn.textContent;
    btn.disabled = true;
    btn.textContent = "Memproses...";
    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        location.replace("dashboard.html");
      } else {
        const { data: res, error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        if (res.session) {
          location.replace("dashboard.html");
        } else {
          show("Akun dibuat. Cek email kamu untuk konfirmasi, lalu masuk.", "ok");
          setMode("login");
          msg.classList.remove("hidden");
        }
      }
    } catch (err) {
      show(translateAuthError(err));
    } finally {
      btn.disabled = false;
      btn.textContent = label === "Memproses..." ? (mode === "login" ? "Masuk" : "Daftar") : label;
    }
  });
}
