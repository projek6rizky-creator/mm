const KEY = "jadwalin-theme";

export function applyTheme(theme) {
  const t = theme === "dark" ? "dark" : "light";
  document.documentElement.setAttribute("data-theme", t);
  try { localStorage.setItem(KEY, t); } catch (_) { /* abaikan */ }
  return t;
}

export function currentTheme() {
  return document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light";
}

// Terapkan tema tersimpan sedini mungkin (mencegah kedipan putih)
export function initThemeEarly() {
  let t = "light";
  try { t = localStorage.getItem(KEY) || "light"; } catch (_) { /* abaikan */ }
  document.documentElement.setAttribute("data-theme", t === "dark" ? "dark" : "light");
}

initThemeEarly();
