import { initPage, esc, fmt, safeColor, todayDow, toast, errorMessage, confirmDialog, DAYS } from "./app.js";
import {
  getSchedules, getSubjects, getOrCreateSubject, addSchedule, updateSchedule, deleteSchedule,
  findConflicts, toMinutes,
} from "../services/jadwal-service.js";
import { refreshReminderData } from "./reminder.js";

let ctx, all = [], subjects = [];
let selected = todayDow(); // 0 = semua hari

const sortFn = (a, b) => toMinutes(a.start_time) - toMinutes(b.start_time);
const subjName = (s) => (s.subjects ? s.subjects.name : "Pelajaran");

function lessonRow(s) {
  return `
    <div class="lesson" style="--lesson-color:${safeColor(s.subjects && s.subjects.color)}">
      <div class="lesson-time">${fmt(s.start_time)} – ${fmt(s.end_time)}</div>
      <div class="lesson-info">
        <div class="lesson-title">${esc(subjName(s))}</div>
        <div class="lesson-meta">${[s.teacher, s.room].filter(Boolean).map(esc).join(" · ") || "&nbsp;"}</div>
      </div>
      <div class="lesson-actions">
        <button class="btn btn-secondary btn-sm" data-edit="${s.id}">Edit</button>
        <button class="btn btn-ghost btn-sm" data-del="${s.id}">Hapus</button>
      </div>
    </div>`;
}

function miniCard(s) {
  return `
    <div class="mini" style="--lesson-color:${safeColor(s.subjects && s.subjects.color)};cursor:pointer" data-edit="${s.id}">
      <b>${esc(subjName(s))}</b>
      ${fmt(s.start_time)}–${fmt(s.end_time)}
      ${s.room ? `<div class="muted">${esc(s.room)}</div>` : ""}
    </div>`;
}

function render() {
  const page = ctx.page;
  const tabs = [`<button class="day-tab ${selected === 0 ? "active" : ""}" data-day="0">Semua</button>`]
    .concat(DAYS.map((d, i) => `<button class="day-tab ${selected === i + 1 ? "active" : ""}" data-day="${i + 1}">${d}</button>`))
    .join("");

  let body;
  if (selected === 0) {
    const cols = DAYS.map((d, i) => {
      const list = all.filter((s) => s.day_of_week === i + 1).sort(sortFn);
      return `<div class="week-col ${i + 1 === todayDow() ? "today" : ""}">
        <h3>${d}</h3>
        ${list.length ? list.map(miniCard).join("") : `<div class="muted" style="font-size:.8rem">Kosong</div>`}
      </div>`;
    }).join("");
    body = `<div class="week-grid">${cols}</div>`;
  } else {
    const list = all.filter((s) => s.day_of_week === selected).sort(sortFn);
    body = list.length
      ? `<div class="lesson-list">${list.map(lessonRow).join("")}</div>`
      : `<div class="empty">Belum ada pelajaran di hari ${DAYS[selected - 1]}.</div>`;
  }

  page.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;gap:1rem;margin-bottom:1rem;flex-wrap:wrap">
      <p class="muted" style="margin:0">Jadwal mingguan Senin – Minggu</p>
      <button class="btn" id="add-btn">+ Tambah jadwal</button>
    </div>
    <div class="day-tabs">${tabs}</div>
    <div class="card">${body}</div>`;

  page.querySelectorAll("[data-day]").forEach((b) =>
    b.addEventListener("click", () => { selected = Number(b.dataset.day); render(); }));
  page.querySelectorAll("[data-edit]").forEach((b) =>
    b.addEventListener("click", () => openForm(all.find((x) => x.id === b.dataset.edit))));
  page.querySelectorAll("[data-del]").forEach((b) =>
    b.addEventListener("click", () => onDelete(all.find((x) => x.id === b.dataset.del))));
  document.getElementById("add-btn").addEventListener("click", () => openForm(null));
}

async function reload() {
  all = await getSchedules();
  subjects = await getSubjects();
  refreshReminderData();
  render();
}

async function onDelete(s) {
  if (!s) return;
  const ok = await confirmDialog(`Hapus jadwal ${subjName(s)} (${fmt(s.start_time)}–${fmt(s.end_time)})?`);
  if (!ok) return;
  try {
    await deleteSchedule(s.id);
    toast("Jadwal dihapus", "ok");
    await reload();
  } catch (err) {
    toast("Gagal menghapus: " + errorMessage(err), "error");
  }
}

function openForm(existing) {
  const editing = !!existing;
  const back = document.createElement("div");
  back.className = "modal-backdrop";
  const daySel = existing ? existing.day_of_week : (selected || todayDow());
  back.innerHTML = `
    <form class="modal" id="sched-form" novalidate>
      <h2>${editing ? "Edit jadwal" : "Tambah jadwal"}</h2>
      <div id="form-msg" class="alert hidden"></div>
      <div class="field">
        <label for="f-subject">Mata pelajaran</label>
        <input class="input" id="f-subject" list="subject-list" maxlength="60" placeholder="mis. Matematika"
          value="${editing ? esc(subjName(existing)) : ""}" autocomplete="off" />
        <datalist id="subject-list">${subjects.map((s) => `<option value="${esc(s.name)}"></option>`).join("")}</datalist>
      </div>
      <div class="row">
        <div class="field">
          <label for="f-day">Hari</label>
          <select class="input" id="f-day">
            ${DAYS.map((d, i) => `<option value="${i + 1}" ${daySel === i + 1 ? "selected" : ""}>${d}</option>`).join("")}
          </select>
        </div>
        <div class="field">
          <label for="f-color">Warna</label>
          <input class="input" type="color" id="f-color" style="padding:.2rem;height:2.6rem"
            value="${safeColor(editing && existing.subjects ? existing.subjects.color : "#4f46e5")}" />
        </div>
      </div>
      <div class="row">
        <div class="field">
          <label for="f-start">Jam mulai</label>
          <input class="input" type="time" id="f-start" value="${editing ? fmt(existing.start_time) : ""}" />
        </div>
        <div class="field">
          <label for="f-end">Jam selesai</label>
          <input class="input" type="time" id="f-end" value="${editing ? fmt(existing.end_time) : ""}" />
        </div>
      </div>
      <div class="row">
        <div class="field">
          <label for="f-teacher">Guru (opsional)</label>
          <input class="input" id="f-teacher" maxlength="80" value="${editing ? esc(existing.teacher) : ""}" />
        </div>
        <div class="field">
          <label for="f-room">Ruang (opsional)</label>
          <input class="input" id="f-room" maxlength="40" value="${editing ? esc(existing.room) : ""}" />
        </div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-secondary" id="cancel-btn">Batal</button>
        <button type="submit" class="btn" id="save-btn">Simpan</button>
      </div>
    </form>`;
  document.body.appendChild(back);

  const $ = (id) => back.querySelector("#" + id);
  const msg = $("form-msg");
  const saveBtn = $("save-btn");
  let conflictAcknowledged = false;

  const close = () => back.remove();
  const show = (text, type = "error") => {
    msg.className = `alert alert-${type}`;
    msg.textContent = text;
  };
  $("cancel-btn").addEventListener("click", close);
  back.addEventListener("mousedown", (e) => { if (e.target === back) close(); });

  // kalau waktu/hari berubah, peringatan bentrok perlu dicek ulang
  ["f-day", "f-start", "f-end"].forEach((id) =>
    $(id).addEventListener("input", () => {
      conflictAcknowledged = false;
      saveBtn.textContent = "Simpan";
      msg.className = "alert hidden";
    }));

  $("sched-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (saveBtn.disabled) return; // cegah kirim ganda

    const name = $("f-subject").value.trim();
    const start = $("f-start").value;
    const end = $("f-end").value;
    const day = Number($("f-day").value);

    if (!name) return show("Nama mata pelajaran wajib diisi.");
    if (!start || !end) return show("Jam mulai dan jam selesai wajib diisi.");
    if (toMinutes(end) <= toMinutes(start)) return show("Jam selesai harus lebih besar dari jam mulai.");

    const candidate = { day_of_week: day, start_time: start, end_time: end };
    const conflicts = findConflicts(all, candidate, editing ? existing.id : null);
    if (conflicts.length && !conflictAcknowledged) {
      const list = conflicts.map((c) => `${subjName(c)} (${fmt(c.start_time)}–${fmt(c.end_time)})`).join(", ");
      show(`Jadwal bentrok dengan: ${list}. Klik "Tetap simpan" kalau memang sengaja.`, "warn");
      conflictAcknowledged = true;
      saveBtn.textContent = "Tetap simpan";
      return;
    }

    saveBtn.disabled = true;
    saveBtn.textContent = "Menyimpan...";
    try {
      const subjectId = await getOrCreateSubject(ctx.user.id, name, $("f-color").value);
      const row = {
        subject_id: subjectId,
        day_of_week: day,
        start_time: start,
        end_time: end,
        teacher: $("f-teacher").value.trim() || null,
        room: $("f-room").value.trim() || null,
      };
      if (editing) await updateSchedule(existing.id, row);
      else await addSchedule({ ...row, user_id: ctx.user.id });
      close();
      toast(editing ? "Jadwal diperbarui" : "Jadwal ditambahkan", "ok");
      selected = day;
      await reload();
    } catch (err) {
      show("Gagal menyimpan: " + errorMessage(err));
      saveBtn.disabled = false;
      saveBtn.textContent = conflictAcknowledged ? "Tetap simpan" : "Simpan";
    }
  });

  $("f-subject").focus();
}

(async function main() {
  ctx = await initPage({ active: "jadwal", title: "Jadwal" });
  if (!ctx) return;
  try {
    all = await getSchedules();
    subjects = await getSubjects();
  } catch (err) {
    ctx.page.innerHTML = `<div class="alert alert-error">Gagal memuat jadwal: ${esc(errorMessage(err))}</div>
      <button class="btn" id="retry">Coba lagi</button>`;
    document.getElementById("retry").addEventListener("click", () => location.reload());
    return;
  }
  render();
  if (new URLSearchParams(location.search).get("add") === "1") {
    history.replaceState(null, "", "jadwal.html");
    openForm(null);
  }
})();
