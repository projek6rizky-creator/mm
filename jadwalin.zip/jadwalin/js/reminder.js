// Pengingat pelajaran lewat Browser Notifications.
// Catatan: hanya berjalan saat tab Jadwalin terbuka. Web Push (saat website
// tertutup) belum diimplementasikan, butuh service worker + server push.

const state = {
  enabled: false,
  minutes: 10,
  getSchedules: null,
  onNotify: null,
  schedules: [],
  fired: new Set(),
  timer: null,
  refreshTimer: null,
};

const toMin = (t) => {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};

export function notificationsSupported() {
  return typeof window !== "undefined" && "Notification" in window;
}

export async function requestPermission() {
  if (!notificationsSupported()) return "unsupported";
  if (Notification.permission === "granted") return "granted";
  if (Notification.permission === "denied") return "denied";
  try { return await Notification.requestPermission(); } catch (_) { return "denied"; }
}

async function refresh() {
  if (!state.getSchedules) return;
  try { state.schedules = await state.getSchedules(); } catch (e) { console.error(e); }
}

function tick() {
  if (!state.enabled) return;
  const now = new Date();
  const dow = now.getDay() === 0 ? 7 : now.getDay();
  const nowMin = now.getHours() * 60 + now.getMinutes() + now.getSeconds() / 60;
  const dateKey = now.toDateString();

  state.schedules
    .filter((s) => s.day_of_week === dow)
    .forEach((s) => {
      const diff = toMin(s.start_time) - nowMin; // menit sampai mulai
      const key = `${s.id}|${dateKey}|${state.minutes}`;
      if (diff > 0 && diff <= state.minutes && !state.fired.has(key)) {
        state.fired.add(key);
        const name = (s.subjects && s.subjects.name) || "Pelajaran";
        const mins = Math.max(1, Math.round(diff));
        const body = `${name} dimulai dalam ${mins} menit (${s.start_time.slice(0, 5)}${s.room ? ", " + s.room : ""})`;
        if (notificationsSupported() && Notification.permission === "granted") {
          try { new Notification("Jadwalin", { body }); } catch (_) { /* abaikan */ }
        }
        if (state.onNotify) state.onNotify(body);
      }
    });
}

export function configureReminders({ enabled, minutes }) {
  if (typeof enabled === "boolean") state.enabled = enabled;
  if (minutes) state.minutes = Number(minutes);
}

export async function startReminders({ getSchedules, enabled, minutes, onNotify }) {
  state.getSchedules = getSchedules;
  state.onNotify = onNotify;
  configureReminders({ enabled, minutes });

  clearInterval(state.timer);
  clearInterval(state.refreshTimer);
  await refresh();
  state.timer = setInterval(tick, 20 * 1000);
  state.refreshTimer = setInterval(refresh, 5 * 60 * 1000);
  tick();
}

// Dipanggil halaman jadwal setelah ada perubahan data
export function refreshReminderData() { return refresh(); }
