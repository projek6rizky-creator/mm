import { initPage, esc, fmt, safeColor, todayDow, nowMinutes, toast, errorMessage, DAYS } from "./app.js";
import { getSchedules, toMinutes } from "../services/jadwal-service.js";

function lessonHtml(s, nowMin, isToday) {
  const done = isToday && toMinutes(s.end_time) <= nowMin;
  const color = safeColor(s.subjects && s.subjects.color);
  return `
    <div class="lesson ${done ? "done" : ""}" style="--lesson-color:${color}">
      <div class="lesson-time">${fmt(s.start_time)} – ${fmt(s.end_time)}</div>
      <div class="lesson-info">
        <div class="lesson-title">${esc(s.subjects ? s.subjects.name : "Pelajaran")}</div>
        <div class="lesson-meta">${[s.teacher, s.room].filter(Boolean).map(esc).join(" · ") || "&nbsp;"}</div>
      </div>
    </div>`;
}

// Cari pelajaran berikutnya: hari ini yang belum mulai, kalau tidak ada cari di hari-hari berikutnya
function findNext(all, nowMin) {
  const today = todayDow();
  for (let offset = 0; offset < 7; offset++) {
    const dow = ((today - 1 + offset) % 7) + 1;
    const list = all
      .filter((s) => s.day_of_week === dow)
      .filter((s) => offset > 0 || toMinutes(s.start_time) > nowMin)
      .sort((a, b) => toMinutes(a.start_time) - toMinutes(b.start_time));
    if (list.length) return { lesson: list[0], offset, dow };
  }
  return null;
}

function render(page, all) {
  const nowMin = nowMinutes();
  const today = todayDow();
  const todays = all
    .filter((s) => s.day_of_week === today)
    .sort((a, b) => toMinutes(a.start_time) - toMinutes(b.start_time));
  const next = findNext(all, nowMin);

  let nextHtml;
  if (next) {
    const when = next.offset === 0 ? "Hari ini" : next.offset === 1 ? "Besok" : DAYS[next.dow - 1];
    nextHtml = `
      <div class="muted">Pelajaran berikutnya · ${when}</div>
      <h2>${esc(next.lesson.subjects ? next.lesson.subjects.name : "Pelajaran")}</h2>
      <div>${fmt(next.lesson.start_time)} – ${fmt(next.lesson.end_time)}</div>
      <div class="muted">${[next.lesson.teacher, next.lesson.room].filter(Boolean).map(esc).join(" · ")}</div>`;
  } else {
    nextHtml = `<div class="muted">Pelajaran berikutnya</div><h2>Belum ada jadwal</h2><div class="muted">Tambah jadwal pertama kamu.</div>`;
  }

  page.innerHTML = `
    <div class="grid grid-3" style="margin-bottom:1rem">
      <div class="card">
        <div class="stat-label">Hari ini · ${DAYS[today - 1]}</div>
        <div class="stat-value">${todays.length}</div>
        <div class="muted">pelajaran</div>
      </div>
      <div class="card next-card" style="grid-column: span 2">${nextHtml}</div>
    </div>
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:1rem;margin-bottom:1rem;flex-wrap:wrap">
        <h2 style="margin:0">Jadwal hari ini</h2>
        <a class="btn btn-sm" href="jadwal.html?add=1">+ Tambah jadwal</a>
      </div>
      ${
        todays.length
          ? `<div class="lesson-list">${todays.map((s) => lessonHtml(s, nowMin, true)).join("")}</div>`
          : `<div class="empty">Tidak ada pelajaran hari ini 🎉</div>`
      }
    </div>`;
}

(async function main() {
  const ctx = await initPage({ active: "dashboard", title: "Dashboard" });
  if (!ctx) return;
  const { page } = ctx;

  let all = [];
  try {
    all = await getSchedules();
  } catch (err) {
    page.innerHTML = `<div class="alert alert-error">Gagal memuat jadwal: ${esc(errorMessage(err))}</div>
      <button class="btn" id="retry">Coba lagi</button>`;
    document.getElementById("retry").addEventListener("click", () => location.reload());
    toast("Gagal memuat jadwal", "error");
    return;
  }

  render(page, all);
  setInterval(() => render(page, all), 60 * 1000); // segarkan status & pelajaran berikutnya
})();
