-- Jadwalin: schema database (Supabase PostgreSQL)
-- Jalankan di Supabase Dashboard > SQL Editor, lalu jalankan policies.sql

create extension if not exists "pgcrypto";

-- ========== profiles ==========
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

-- ========== subjects ==========
create table if not exists public.subjects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  color text default '#4f46e5',
  created_at timestamptz not null default now(),
  unique (id, user_id)
);

-- ========== schedules ==========
create table if not exists public.schedules (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject_id uuid not null,
  day_of_week integer not null check (day_of_week between 1 and 7),
  start_time time not null,
  end_time time not null,
  teacher text,
  room text,
  created_at timestamptz not null default now(),
  constraint schedules_time_valid check (end_time > start_time),
  -- subject harus dimiliki user yang sama
  constraint schedules_subject_owner_fk
    foreign key (subject_id, user_id)
    references public.subjects (id, user_id) on delete cascade
);

create index if not exists schedules_user_day_idx
  on public.schedules (user_id, day_of_week, start_time);

-- ========== user_settings ==========
create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  theme text not null default 'light' check (theme in ('light', 'dark')),
  reminder_enabled boolean not null default false,
  reminder_minutes integer not null default 10 check (reminder_minutes in (5, 10, 15)),
  updated_at timestamptz not null default now()
);

-- ========== auto-buat profile + settings saat user daftar ==========
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, split_part(new.email, '@', 1))
  on conflict (id) do nothing;

  insert into public.user_settings (user_id)
  values (new.id)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
