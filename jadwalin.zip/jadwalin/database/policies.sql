-- Jadwalin: Row Level Security policies
-- Jalankan SETELAH schema.sql

alter table public.profiles enable row level security;
alter table public.subjects enable row level security;
alter table public.schedules enable row level security;
alter table public.user_settings enable row level security;

-- ========== profiles ==========
drop policy if exists "profiles_select_own" on public.profiles;
drop policy if exists "profiles_insert_own" on public.profiles;
drop policy if exists "profiles_update_own" on public.profiles;

create policy "profiles_select_own" on public.profiles
  for select using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles
  for insert with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

-- ========== subjects ==========
drop policy if exists "subjects_all_own" on public.subjects;
create policy "subjects_all_own" on public.subjects
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ========== schedules ==========
drop policy if exists "schedules_all_own" on public.schedules;
create policy "schedules_all_own" on public.schedules
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ========== user_settings ==========
drop policy if exists "settings_all_own" on public.user_settings;
create policy "settings_all_own" on public.user_settings
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
