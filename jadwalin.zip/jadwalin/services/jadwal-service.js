import { supabase } from "./supabase.js";

// Ambil semua jadwal milik user (RLS otomatis membatasi ke user yang login)
export async function getSchedules() {
  const { data, error } = await supabase
    .from("schedules")
    .select("id, subject_id, day_of_week, start_time, end_time, teacher, room, subjects(id, name, color)")
    .order("day_of_week")
    .order("start_time");
  if (error) throw error;
  return data;
}

// Cari subject berdasarkan nama; buat baru jika belum ada
export async function getOrCreateSubject(userId, name, color) {
  const clean = name.trim();
  const { data: found, error: findErr } = await supabase
    .from("subjects")
    .select("id, name, color")
    .eq("user_id", userId)
    .ilike("name", clean)
    .maybeSingle();
  if (findErr) throw findErr;
  if (found) {
    if (color && found.color !== color) {
      await supabase.from("subjects").update({ color }).eq("id", found.id);
    }
    return found.id;
  }
  const { data, error } = await supabase
    .from("subjects")
    .insert({ user_id: userId, name: clean, color })
    .select("id")
    .single();
  if (error) throw error;
  return data.id;
}

export async function getSubjects() {
  const { data, error } = await supabase.from("subjects").select("id, name, color").order("name");
  if (error) throw error;
  return data;
}

export async function addSchedule(row) {
  const { error } = await supabase.from("schedules").insert(row);
  if (error) throw error;
}

export async function updateSchedule(id, row) {
  const { error } = await supabase.from("schedules").update(row).eq("id", id);
  if (error) throw error;
}

export async function deleteSchedule(id) {
  const { error } = await supabase.from("schedules").delete().eq("id", id);
  if (error) throw error;
}

// Helper waktu: "HH:MM[:SS]" -> menit sejak 00:00
export function toMinutes(t) {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

// Kembalikan jadwal yang bentrok dengan kandidat (hari sama, waktu overlap)
export function findConflicts(all, candidate, ignoreId = null) {
  const s = toMinutes(candidate.start_time);
  const e = toMinutes(candidate.end_time);
  return all.filter((x) => {
    if (ignoreId && x.id === ignoreId) return false;
    if (x.day_of_week !== candidate.day_of_week) return false;
    return s < toMinutes(x.end_time) && e > toMinutes(x.start_time);
  });
}
