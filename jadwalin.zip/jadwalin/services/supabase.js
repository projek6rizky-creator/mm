// Konfigurasi Supabase.
// Isi dengan Project URL dan anon (public) key dari:
// Supabase Dashboard > Project Settings > API.
// JANGAN pernah memakai service_role key di frontend.
// Lihat .env.example untuk contoh nilainya.
export const SUPABASE_URL = "https://YOUR-PROJECT-ID.supabase.co";
export const SUPABASE_ANON_KEY = "YOUR-ANON-PUBLIC-KEY";

import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";

export const isConfigured =
  !SUPABASE_URL.includes("YOUR-PROJECT-ID") && !SUPABASE_ANON_KEY.includes("YOUR-ANON");

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
