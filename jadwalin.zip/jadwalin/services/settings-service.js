import { supabase } from "./supabase.js";

const DEFAULTS = { theme: "light", reminder_enabled: false, reminder_minutes: 10 };

export async function getSettings(userId) {
  const { data, error } = await supabase
    .from("user_settings")
    .select("theme, reminder_enabled, reminder_minutes")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw error;
  return data || { ...DEFAULTS };
}

export async function saveSettings(userId, patch) {
  const { error } = await supabase
    .from("user_settings")
    .upsert({ user_id: userId, ...patch, updated_at: new Date().toISOString() });
  if (error) throw error;
}

export async function getProfile(userId) {
  const { data, error } = await supabase
    .from("profiles")
    .select("display_name")
    .eq("id", userId)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function saveProfile(userId, display_name) {
  const { error } = await supabase.from("profiles").upsert({ id: userId, display_name });
  if (error) throw error;
}
